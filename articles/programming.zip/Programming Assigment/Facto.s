.globl main
.data
  first: .asciiz "\nInteger: "
  second: .asciiz "The Factorial("
  third: .asciiz ") is: "
  fourth: .asciiz "Boundary error message "

.text
main:
  #This is going to be printing the first
  la $a0, first
  li $v0, 4
  syscall

  # reading the input int
  li      $v0, 5            # call code for read_int
  syscall                   # run the read_int syscall
  move    $t0, $v0          # This will be storing our input in t0

  #What this is doing is making sure that if the factorial is 12 or above if it is then we are going to have a boundary error message.
  move    $a0, $t0
  blt     $a0, $zero, follow
  addi    $a1, $zero, 12
  ble     $a0, $a1, other
follow:
  la      $a0, fourth
  li      $v0, 4
  syscall
  j exit #It will send it to exit to end the program. 
  #Other is the jump we make if the number is below 12
other:  
  addi    $sp, $sp, -12     # It will be moving the stackpointer up 3 words
  sw      $t0, 0($sp)       # store input in top of stack
  sw      $ra, 8($sp)       # store counter at bottom of stack
  jal     factorial         # call factorial

 #This lw is very important because we are saving the final value into s0

  lw      $s0, 4($sp) 

  # This is going to print the second 
  li      $v0, 4            # system call for print_string
  la      $a0, second      # load msgres1 address into $t1
  syscall                   # print value of msgres1_data to screen

  lw      $a0, 0($sp)       # load original value into $a0
  li      $v0, 1            # system call for print_int
  syscall                   # print original value to screen
  #  This is going to be printing the third

  li      $v0, 4            # system call for print_string
  la      $a0, third      #load msgres2 address into $t1
  syscall                   # print value of msgres2_data to screen

  move    $a0, $s0          # move final return value from $s0 to $a0 for return
  li      $v0, 1            # system call for print_int
  syscall                   # print final return value
  addi    $sp, $sp, 12      # we are moving the stock pointer where it started

exit:
  li      $v0, 10           # system call for exit
  syscall                   # exit



.text
factorial:
  # base  case - still in parent's stack segment
  lw      $t0, 0($sp)       # load input from top of stack into register $t0

  #if x==0 then jump to if
  beq     $t0, $zero, if    # if $t0 is equal to 0, go to if
  addi    $t0, $t0, -1      # subtract 1 from $t0 if not equal to 0

  addi    $sp, $sp, -12
  sw      $t0, 0($sp)       # store current working number into the top of the stack segment
  sw      $ra, 8($sp)       # store counter at bottom of stack segment

  jal     factorial         # recursive

  # if we get here, then we have the child return value in 4($sp)
  lw      $ra, 8($sp)       # load this call's $ra again(we just got back from a jump)
  lw      $t1, 4($sp)       # load child's return value into $t1

  lw      $t2, 12($sp)      # load parent's start value into $t2
  #Mostly what this is doing is x * (x-1) which is parent times son. 
  mul     $t3, $t1, $t2    
  sw      $t3, 16($sp)      
  addi    $sp, $sp, 12 
  jr      $ra               # jump to parent call

.text
#because x == 0 then its returning 1
if:
  li      $t0, 1            # load 1 into register $t0
  sw      $t0, 4($sp)       # store 1 into the parent's return value register
  jr      $ra               # jump to parent call