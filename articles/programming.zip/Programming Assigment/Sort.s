
.data
.align 4
Array: .space 200
firstm: .asciiz "How many numbers would you like to enter? "
secondm: .asciiz "Enter number: \n "
thirdm: .asciiz "\nYou have entered: "
fourthm: .asciiz "\nHere is the sorted list in ascending order : "
fifthm: .asciiz " "

.text
.globl main
main:

#This is the one that is calling firstm
li $v0,4
la $a0,firstm #Printing the first message
syscall
li $v0,5
syscall
move $s0,$v0 #This one gets the size of the array

addi $t0,$zero,0


first:
#prompt for integer
bge $t0,$s0,finish	#It checks when to stop the loop, if not it will be infinite
li $v0,4
la $a0,secondm
syscall				#Calling the second message
li $v0,5
syscall				#To be able to put the numbers

add $t1,$t0,$zero
sll $t1,$t0,2
add $t3,$v0,$zero
sw $t3, Array($t1)	#storing the data at location
addi $t0,$t0,1

slt $t1,$s0,$t0
j first #jump to read more data

finish:
#reduce s0 by 1 as zero based index
addi $s0,$s0,-1

li $v0,4
la $a0,thirdm #This one it will be printing out the third message
syscall
jal printArray

la $a0,Array
addi $a1,$s0,1 #a1=6
#call buble_sort
jal buble_sort

addi $s5,$s0,1 #get number of element

#This will be printing the array
li $v0,4
la $a0,fourthm
syscall
jal printArray
li $v0,10
syscall

buble_sort:
add $t0,$zero,$zero #t0 = 0, this is very important because it restart the values.

loop:
addi $t0,$t0,1 #t0= t0 + 1
blt $t0,$a1,keep #if t0 < a1 keep  
keep:
addi $t1,$a1,0 #storing a1 into t1 to be able to do the comparison; a1 is the size and a0 is the memory address
jr $ra 	#end
loop2:

bge $t0,$t1,loop #t0 < t1

#This is the bubble sort mostly what I am doing is checking the number with each until the loop is finish
addi $t1,$t1,-1 #t1 = t1 -1
mul $t3,$t1,4 #t3 = t1 * 4
addi $t2,$t3,-4 #t2 = t3 - 4
add $t5,$t2,$a0 #t5 = t2 +a0
add $t4,$t3,$a0 #t4 = t3 +a0
lw $t6,0($t4)
lw $t7,0($t5)

bgt $t6,$t7,loop2 #t6 < t7

#This is switching t5, t6

sw $t7,0($t4)
sw $t6,0($t5)
j loop2

#This will print all the integers
printArray:
la $t0,Array
addi $t1,$zero,0
other:
lw $a0,0($t0)
li $v0,1
syscall
#This call is for leaving space after each element
li $v0,4
la $a0,fifthm
syscall
#This loop is to arrange all the numbers and repeat until there are none left
addi $t0,$t0,4
addi $t1,$t1,1
slt $t2,$s0,$t1
beq $t2,$zero,other
jr $ra 	#end